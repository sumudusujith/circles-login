export const routesClass = {
  user_url: "http://localhost:5000",
  routeToLogin: "/login",
  routeToDashboard: "./dashboard",
  errorMessage: "Please check your login credentials",
};