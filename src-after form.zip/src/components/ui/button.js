import React from "react";
import { Button } from "rebass";

export const RebassButton = ({ value }) => {
  return <Button>{value}</Button>;
};
