export const  INCREMENT =  "INCREMENT"
export const DECREMENT = "DECREMENT"
export const LOGIN = "LOGIN"
export const SAGA_LOGIN = "SAGA_LOGIN" //q
export const LOGIN_RESPONSE = "LOGIN_RESPONSE"
export const FORM_LOGIN = "FORM_LOGIN"
export const FORM_RESPONSE = "FORM_RESPONSE"

//export const LOGIN_RESPONSE = "LOGIN_RESPONSE"


