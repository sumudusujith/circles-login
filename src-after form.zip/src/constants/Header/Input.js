import React from "react";
import { Input } from "@rebass/forms";

export const RebassInput = ({ name, fontFamily, border }) => {
  return <Input></Input>;
};
